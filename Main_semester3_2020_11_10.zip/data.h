#ifndef DATA_H
#define DATA_H
#endif

int CheckWinner(int coord, int width, int height);