#ifndef DEFINES_H
#define DEFINES_H
#endif 

#define boardHeight 5
#define boardWidth 5
#define buttonSize 40
#define winAmount 3

#define File_Menu_Exit 10001
#define File_Menu_New 10002
#define File_Menu_Open 10003
#define Tools_Menu_Reset 10004
