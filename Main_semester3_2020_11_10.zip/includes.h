#ifndef INCLUDES_H
#define INCLUDES_H
#endif

#include <stdio.h>            // Standard Ein- und Ausgabe
#include <windows.h>          // Betriebssystemfunktionen
#include <stdlib.h>
#include <string.h>
#include "controll.h"
#include "view.h"
#include "data.h"
#include "defines.h"
